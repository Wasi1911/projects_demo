# Driver-s-Drowsiness-Detection
# Motivation 
1-The drowsiness of a person driving a vehicle is
the primary cause of accidents all over the
world.

2- We have put forward a deep learning and
machine learning based approach to detect the
drowsiness of the drivers.
# Problem Statement
The core problem addressed in a drowsiness
detection system using deep learning model and
KNN model is to identify and prevent instances of
driver drowsiness or fatigue during driving.
# Proposed Solution
The proposed solution involves implementing a
CNN-based and KNN model.
