# WhatsApp-Chat-Analyzer
•	Developed and built a user-friendly web application on Streamlit for the WhatsApp Chat Analyzer, empowering users to easily upload and analyze their one-to-one and group chats. 

•	Utilized Python and data visualization libraries to present comprehensive insights on message count, word usage, media files, shared links, active users, popular words/emojis, and chat activity timelines.

**Note: Chat Must be in AM|PM Format**
